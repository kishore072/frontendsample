create a new file as follows: `submission_your_github_username.html` and send the PR using the following template:

👉   <b>Name of the file: </b> <i>your_github_username.html</i><br/>
👉   <b>Inside the file, paste your codedamn's submission URL. </b> The format is: <i>`https://codedamn.com/project/solution/:id`</i><br/>
👉   <b>Write your Email ID, Github username, and name<br/>
👉   <b>Send a Pull Request</b> to `main` branch<br/>
